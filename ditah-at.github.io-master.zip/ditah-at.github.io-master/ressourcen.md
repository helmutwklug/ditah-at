﻿---
layout: page
title: Ressourcen
hero_height: is-small
permalink: /ressourcen/
---

# Ressourcen

**Projektplattform unter Google Drive (Zugriff nur für eingeladene Personen):**  
[https://drive.google.com/drive/folders/1wmBaHGVQMIuO6QQd6oty8QaBw2BLxWuG?usp=sharing](https://drive.google.com/drive/folders/1wmBaHGVQMIuO6QQd6oty8QaBw2BLxWuG?usp=sharing)

**Mailingliste:**  
[http://list.uni-graz.at/mailman/listinfo/ditah](http://list.uni-graz.at/mailman/listinfo/ditah)

**DiTAH auf Github:**  
[https://github.com/ditah-at](https://github.com/ditah-at)

**Blog Cluster Bilddaten:**    
[https://bilddaten.hypotheses.org/](https://bilddaten.hypotheses.org/)
