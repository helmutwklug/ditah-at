﻿---
layout: page
title: Partner
image: /assets/img/ditahicons/Netzwerk.png
hero_height: is-small
permalink: /partner/
---

* Universität Graz (Projektkoordination)
* Akademie der bildenden Künste, Wien
* Donau-Universität Krems
* Österreichische Akademie der Wissenschaften
* Österreichische Nationalbibliothek
* Paris-Lodron-Universität Salzburg
* Universität Innsbruck
* Universität Wien
* Technische Universität Wien