---
layout: page
title: Impressum
hero_height: is-small
permalink: /impressum/
---

**Projektleitung**  
Georg Vogeler  
Zentrum für Informationsmodellierung  
Karl-Franzens-Universität Graz   
georg.vogeler@uni-graz.at

**Projektkoordination und Redaktion Website**  
Helmut Klug   
Zentrum für Informationsmodellierung  
Karl-Franzens-Universität Graz  
helmut.klug@uni-graz.at  

**Finanzierung:**  
„Digitale und soziale Transformation in der Hochschulbildung“        
Bundesministerium für Wissenschaft, Forschung und Wirtschaft  

**Lizenzierung der bereitgestellten Inhalte**  
Creative Commons CC-BY  

**Die Informationen und Dienste auf dieser Seite werden zur Verfügung gestellt von**  
Karl-Franzens-Universität Graz  
Universitätsplatz 3  
8010 Graz, Österreich  
E-Mail: zim@uni-graz.at  
Tel.: +43-(0)316 380 2292  


